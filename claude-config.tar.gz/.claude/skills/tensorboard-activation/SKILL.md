---
name: tensorboard-activation
description: "Launch and manage TensorBoard for visualizing ML training metrics. Use when: (1) the user asks to start, open, launch, or activate TensorBoard, (2) the user wants to view training logs, loss curves, or metrics dashboards, (3) the user asks to forward TensorBoard via SSH, (4) the user provides a training output directory and wants to visualize it, (5) the user mentions TensorBoard port forwarding or remote access."
---

# TensorBoard Launcher

## Workflow

### 1. Identify the log directory

- If the user provides a path, use it. Look for a `tensorboard/` subdirectory within it.
- If not provided, search for recent TensorBoard event files:
  ```bash
  find <project>/output -name 'events.out.tfevents.*' -printf '%T@ %p\n' | sort -rn | head -5
  ```
- Validate the directory contains `events.out.tfevents.*` files before proceeding.

### 2. Launch TensorBoard

Run the bundled launch script:

```bash
bash <skill-dir>/scripts/launch_tensorboard.sh <logdir> [port]
```

Default port is 6006. The script handles:
- Killing any existing process on the port (via `fuser` or `lsof`)
- Confirming the port is free
- Starting TensorBoard with `nohup` and `--bind_all`
- Verifying HTTP 200 response within 10 seconds

### 3. Provide access instructions

After successful launch, provide:

1. **Local URL**: `http://localhost:<port>`
2. **SSH tunnel command** (for remote servers):
   ```
   ssh -L <port>:localhost:<port> <ssh-connection>
   ```
3. Remind the user to check the **Scalars** tab for loss/metrics and **Time Series** for detailed views.

### Troubleshooting

If the script fails:
- **Port stuck**: `fuser -k <port>/tcp` or `pkill -9 -f tensorboard`, wait 2s, retry.
- **No event files**: Verify the training run actually wrote TensorBoard logs. Check for `tensorboard/` or `logs/` subdirectories.
- **TensorBoard not installed**: `pip install tensorboard`.

## Resources

### scripts/
- `launch_tensorboard.sh` — Main launch script. Kills old instances, starts TensorBoard, verifies it is serving, and prints access instructions including SSH tunnel command.
